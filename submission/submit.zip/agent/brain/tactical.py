"""
Tactical decision layer.
This module performs purely tactical reasoning.
It never searches.
It never talks to the engine.
It simply evaluates candidate actions produced by the planner
(or rules fallback) and produces additive score adjustments.
Everything here should be stateless.
Later the online learner will optimize the weights.
"""
from __future__ import annotations
from dataclasses import dataclass
from agent.adapter import OptionType

@dataclass
class TacticalWeights:
    attack_bonus: float = 0.0
    ko_bonus: float = 0.0
    retreat_bonus: float = 0.0
    retreat_penalty: float = 0.0
    supporter_bonus: float = 0.0
    item_bonus: float = 0.0
    gust_bonus: float = 0.0
    bench_bonus: float = 0.0
    attach_bonus: float = 0.0
    attach_penalty: float = 0.0
    evolve_bonus: float = 0.0
    discard_penalty: float = 0.0

class TacticalBrain:
    """
    Stateless tactical scorer.
    Future versions will use:
        replay learning
        online RL
        contextual weights
        matchup adjustments
    For now everything is additive.
    """
    def __init__(self, weights: TacticalWeights | None = None):
        self.weights = weights or TacticalWeights()

    def score(
        self,
        obs_dict,
        option,
        gamedata,
    ) -> float:
        t = option.type
        score = 0.0
        if t == OptionType.ATTACK:
            score += self.weights.attack_bonus
        elif t == OptionType.ATTACH:
            score += self.weights.attach_bonus
        elif t == OptionType.EVOLVE:
            score += self.weights.evolve_bonus
        elif t == OptionType.PLAY:
            score += self.weights.item_bonus
        elif t == OptionType.RETREAT:
            score += self.weights.retreat_bonus
        return score