from .tactical import TacticalBrain
from .tactical import TacticalWeights